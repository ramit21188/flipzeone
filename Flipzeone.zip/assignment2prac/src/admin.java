public class admin  {
    private String name;
    private String password;
    private String username;
    private String status="admin";
    admin(String name,String password,String username){
        this.name=name;
        this.username=username;
        this.password=password;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }
}
