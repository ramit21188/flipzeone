public class product {
    private String name;
    private Float id;
    private Float cost;
   public product(String n,Float id,Float cost) {
       this.id=id;
       this.name=n;
       this.cost=cost;

   }

    public String getName() {
        return name;
    }

    public void setId(Float id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getId() {
        return id;
    }

    public void setCost(Float cost) {
        this.cost = cost;
    }

    public Float getCost() {
        return cost;
    }
    public void setdiscount(Float a){
       this.cost=((100-a)/100)*this.cost;
    }
}
