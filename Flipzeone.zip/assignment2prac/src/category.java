import java.util.ArrayList;

public class category {
   private String name;
   private  int id;
   private ArrayList<product>productArrayList=new ArrayList<>();
   public category(String name,int id){
       this.id=id;
       this.name=name;
   }

    public String getName() {
        return name;
    }

    public ArrayList<product> getProductArrayList() {
        return productArrayList;
    }

    public int getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = Integer.parseInt(id);
    }

    public void setProductArrayList(ArrayList<product> productArrayList) {
        this.productArrayList = productArrayList;
    }
}
