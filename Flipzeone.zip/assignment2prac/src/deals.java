public class deals {
    private String p1name;
    private String p2name;
    private Float p1cost;
    private Float p2cost;
    private Float combinedcost;


    public deals(product p1,product p2,Float cost){
        this.p1name=p1.getName();
        this.p2name=p2.getName();
        this.p1cost=p1.getCost();
        this.p2cost=p2.getCost();
        if(p1cost+p2cost>=cost){
            this.combinedcost=cost;
            System.out.println("successsful");
        }
        else{
            System.out.println("invalid deal");
        }


    }

    public Float getP1cost() {
        return p1cost;
    }

    public Float getP2cost() {
        return p2cost;
    }

    public String getP1name() {
        return p1name;
    }

    public String getP2name() {
        return p2name;
    }

    public Float getCombinedcost() {
        return combinedcost;
    }
}
