import java.util.ArrayList;

public  abstract class customer  {
    private Float discount;

    public void setDiscount(Float discount) {
        this.discount = discount;
    }

    public Float getDiscount() {
        return discount;
    }

    Float cost=0.00F;
    Float cost2=0.0F;
    public Float checkoutcart(){
        for(int f=0;f<cart.size();f++){
            product p=cart.get(f);
            cost=cost+p.getCost();}
        for(int f=0;f< dealsArrayList.size();f++){
            deals d=dealsArrayList.get(f);

            cost2=cost2+d.getCombinedcost();}
        cost=((100-discount)/100)*(cost+cost2);

    return cost;}


    public void setCart(ArrayList<product> cart) {
        this.cart = cart;
    }

    public void setDealsArrayList(ArrayList<deals> dealsArrayList) {
        this.dealsArrayList = dealsArrayList;
    }


    private String name;
    private String membership;
    private Float bankbalance;
    private String username;
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    private ArrayList<product>cart=new ArrayList<>();
    private ArrayList<deals>dealsArrayList=new ArrayList<>();

    public ArrayList<deals> getDealsArrayListcus() {
        return dealsArrayList;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setBankbalance(Float bankbalance) {
        this.bankbalance = bankbalance;
    }

    public void setMembership(String membership) {
        this.membership = membership;
    }

    public Float getBankbalance() {
        return bankbalance;
    }

    public String getMembership() {
        return membership;
    }

    public ArrayList<product> getCart() {
        return cart;
    }


}
class normal extends customer implements Cloneable{


    @Override
    public Object clone()throws CloneNotSupportedException{

            return super.clone();}

}
class elite extends customer implements Cloneable{
    @Override
    public Object clone()throws CloneNotSupportedException{

        return super.clone();}


}
class prime extends customer{


}

