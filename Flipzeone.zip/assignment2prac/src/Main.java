import java.sql.SQLOutput;
import java.util.*;
public class Main {

    public static ArrayList<admin>adminArrayList = new ArrayList<>();
    public static ArrayList<category>categoryArrayList=new ArrayList<>();
    public static ArrayList<deals>dealsArrayList=new ArrayList<>();
    public static ArrayList<customer>customerArrayList=new ArrayList<>();
    public static void main(String [] args) throws CloneNotSupportedException {
        customer cn=new normal();
        Scanner sc=new Scanner(System.in);
        while(true){
            int x1;
            System.out.println("Welcome to flipzone!!!!");
            System.out.println(" 1)Enter as admin");
            System.out.println(" 2)Explore product catalog");
            System.out.println(" 3)Show available deals");
            System.out.println(" 4)Enter as customer");
            System.out.println(" 5)exit");
            x1= sc.nextInt();
            if(x1==5){
                break;
            }
            while(true){
            if(x1==1){
                System.out.println("Welcome Admin!!!");
                System.out.println(" 1)Enter as new Admin");
                System.out.println(" 2) Login");


                x1=sc.nextInt();
                if(x1==1){
                    System.out.println("enter name");
                    String n=sc.next();
                    System.out.println("enter username");
                    String u=sc.next();
                    System.out.println("enter password for choice");
                    String p=sc.next();
                    admin a1=new admin(n,p,u);
                    adminArrayList.add(a1);
                    System.out.println("Suceesfull");
                    continue;
                }
                if(x1==2){
                    System.out.println("enter username");
                    String u1= sc.next();
                    System.out.println("enter password");
                    String p1= sc.next();
                    int n=adminArrayList.size();
                    int i=0;
                    while( i<n){
                        admin e1=adminArrayList.get(i);

                        if(Objects.equals(e1.getUsername(), u1) && Objects.equals(e1.getPassword(), p1))  {
                            System.out.println("welcome"+e1.getName());
                            System.out.println(" 1)Add category");
                            System.out.println(" 2)delete category");
                            System.out.println(" 3)Add product");
                            System.out.println(" 4)delete product");
                            System.out.println(" 5)set discount on products");
                            System.out.println(" 6)add giveaway deals");
                            System.out.println(" 7)back");
                            int x2=sc.nextInt();
                            if(x2==7){
                                break;
                            }

                            if(x2==1){
                                System.out.println("enter name of category");
                                String n1=sc.next();
                                int s=categoryArrayList.size()+1;
                                category c=new category(n1,s);
                                categoryArrayList.add(c);
                                System.out.println(c.getId());
                                System.out.println("added successfully!!");

                                continue;}
                            if(x2==2){
                                System.out.println("enter catg. name");
                                String c1=sc.next();
                                for(int k=0;k<categoryArrayList.size();k++){
                                    if(categoryArrayList.get(k).getName().equals(c1)){
                                        categoryArrayList.remove(k);
                                        System.out.println("removed successfully");
                                    }
                                    else if(k==n-1){
                                        System.out.println("no such catg.");
                                        break;
                                    }
                                }
                            }
                            if(x2==3){
                                System.out.println("enter category name");
                                String c2=sc.next();
                                System.out.println("enter product name to be added");
                                String c3=sc.next();
                                for(int k=0;k<categoryArrayList.size();k++){
                                    if(categoryArrayList.get(k).getName().equals(c2)){
                                        System.out.println(categoryArrayList.size());
                                        category e=categoryArrayList.get(k);
                                        System.out.println("enter cost to product ");
                                        Float c= sc.nextFloat();
                                        int fs= e.getProductArrayList().size()+1;
                                        int z=e.getId();
                                        double f1= 1.0*z+0.1*fs;
                                        product p2=new product(c3, (float) f1,c);
                                        e.getProductArrayList().add(p2);
                                        System.out.println(p2.getId());
                                        System.out.println("added successfully");
                                        break;
                                    }
                                    else if(k==categoryArrayList.size()-1){
                                        System.out.println("no such catg.");
                                        break;
                                    }
                                    else{
                                        continue;
                                    }
                                }
                            }
                            if(x2==4){
                                System.out.println("enter category name");
                                String c2=sc.next();
                                System.out.println("enter product name to be removed");
                                String c3=sc.next();
                                for(int k=0;k<categoryArrayList.size();k++){
                                    if(categoryArrayList.get(k).getName().equals(c2)){
                                        category e=categoryArrayList.get(k);
                                        int h=0;
                                        while(h<e.getProductArrayList().size()){
                                            if(e.getProductArrayList().get(h).getName().equals(c3)){
                                                e.getProductArrayList().remove(h);
                                                System.out.println("removed successfully");
                                                break;}
                                            else if(h==e.getProductArrayList().size()-1){
                                                System.out.println("no such product");
                                                h++;}
                                            else{
                                                h++;
                                            }

                                        }

                                    }
                                    else if(k==n-1){
                                        System.out.println("no such catg.");
                                        continue;
                                    }
                                }

                            }
                            if(x2==5){
                                System.out.println("enter category name");
                                String c2=sc.next();
                                System.out.println("enter product name to be discounted");
                                String c3=sc.next();
                                System.out.println("enter discount percentage");
                                Float dp=sc.nextFloat();
                                for(int k=0;k<categoryArrayList.size();k++){
                                    if(categoryArrayList.get(k).getName().equals(c2)){
                                        category e=categoryArrayList.get(k);
                                        int h=0;
                                        while(h<e.getProductArrayList().size()){
                                            if(e.getProductArrayList().get(h).getName().equals(c3)){
                                                e.getProductArrayList().get(h).setdiscount(dp);
                                                System.out.println("operation successfull successfully");
                                                continue;}
                                            else if(h==e.getProductArrayList().size()-1){
                                                System.out.println("no such product");
                                                h++;}
                                            else{
                                                h++;
                                            }

                                        }

                                    }
                                    else if(k==n-1){
                                        System.out.println("no such catg.");
                                        continue;
                                    }
                                }

                            }
                            if(x2==6){
                                product d1=null;
                                product d2 = null;
                                System.out.println("enter category name 1");
                                String c2=sc.next();
                                System.out.println("enter product name to be added to deallist 1");
                                String c3=sc.next();
                                for(int k=0;k<categoryArrayList.size();k++){
                                    if(categoryArrayList.get(k).getName().equals(c2)){
                                        category e=categoryArrayList.get(k);
                                        int h=0;
                                        while(h<e.getProductArrayList().size()){
                                            if(e.getProductArrayList().get(h).getName().equals(c3)){
                                                d1=e.getProductArrayList().get(h);
                                                break;}
                                            else if(h==e.getProductArrayList().size()-1){
                                                System.out.println("no such product");
                                                h++;}
                                            else{
                                                h++;}

                                        }

                                    }
                                    else if(k==n-1){
                                        System.out.println("no such catg.");
                                        continue;
                                    }
                                }
                                System.out.println("enter category name");
                                String c4=sc.next();
                                System.out.println("enter product name to be added");
                                String c5=sc.next();
                                for(int k=0;k<categoryArrayList.size();k++){
                                    if(categoryArrayList.get(k).getName().equals(c4)){
                                        category e=categoryArrayList.get(k);
                                        int h=0;
                                        while(h<e.getProductArrayList().size()){
                                            if(e.getProductArrayList().get(h).getName().equals(c5)){
                                                d2=e.getProductArrayList().get(h);
                                                break;}
                                            else if(h==e.getProductArrayList().size()-1){
                                                System.out.println("no such product");
                                                h++;}
                                            else{
                                                h++;
                                            }

                                        }

                                    }
                                    else if(k==n-1){
                                        System.out.println("no such catg.");
                                        break;
                                    }
                                }
                                System.out.println("enter combined cost");
                                Float cst= sc.nextFloat();
                                assert d2 != null;
                                assert d1 != null;
                                deals d=new deals(d1,d2,cst);
                                dealsArrayList.add(d);




                            }



                        }
                        else{
                            if(i==n-1){
                                System.out.println("invalid details");
                                break;

                            }
                        }


                    i++;}

                break;}






            }

            if(x1==2){

                int size1=categoryArrayList.size();
                if(size1!=0){
                for(int f=0;f<size1;f++){
                    category cat=categoryArrayList.get(f);
                    int size2=cat.getProductArrayList().size();
                    System.out.println(cat.getName());
                    for(int f1=0;f1<size2;f1++){
                        System.out.println(cat.getProductArrayList().get(f1).getName());
                        System.out.println(cat.getProductArrayList().get(f1).getCost());
                    }

                }

                  break;}
            else{
                    System.out.println("no products");
                    break;
                }
            }
            if(x1==3){
                int size1=dealsArrayList.size();
                if(size1!=0){
                for(int x=0;x<size1;x++){
                    deals d3=dealsArrayList.get(x);
                    System.out.println(d3.getP1name()+" "+d3.getP2name());
                    System.out.println(d3.getCombinedcost());

                }
                break;}
                else{
                    System.out.println("no deals");
                    break;
                }
            }
            if(x1==4){

                System.out.println("1) sign in");
                System.out.println("2) log in");
                System.out.println("3) back");
                int x4=sc.nextInt();
                if(x4==3){
                    break;}

                if(x4==1){
                    System.out.println("enter name");
                    String s2=sc.next();
                    System.out.println("enter username");
                    String s3=sc.next();
                    System.out.println("enter password");
                    String s4=sc.next();
                    cn.setBankbalance(1000.00F);
                    cn.setMembership("normal");
                    cn.setName(s2);
                    cn.setUsername(s3);
                    cn.setPassword(s4);
                    cn.setDiscount(0.00F);
                    customerArrayList.add(cn);
                    System.out.println("added successfully");
                     continue;}
                if(x4==2){
                    System.out.println("enter customer username");
                    String uc=sc.next();
                    System.out.println("enter password" );
                    String pc=sc.next();
                    for(int i=0;i<customerArrayList.size();i++){
                        if(customerArrayList.get(i).getUsername().equals(uc)&&customerArrayList.get(i).getPassword().equals(pc)){
                            System.out.println("welocome"+" "+customerArrayList.get(i).getName());
                            while(true){
                            System.out.println("1) browse products");
                            System.out.println("2) browse deals");
                            System.out.println("3) add products to cart");
                            System.out.println("4) add products in deal to cart");
                            System.out.println("5) view coupons");
                            System.out.println("6) check account details");
                            System.out.println("7) view carts");
                            System.out.println("8) empty cart");
                            System.out.println("9) checkout cart");
                            System.out.println("10) upgrade customer status");
                            System.out.println("11) add amount to wallet");
                            System.out.println("12) back");
                            int x5=sc.nextInt();
                            if(x5==12){
                                break;
                            }
                            if(x5==1){
                                int size1=categoryArrayList.size();
                                if(size1!=0){
                                    for(int f=0;f<size1;f++){
                                        category cat=categoryArrayList.get(f);
                                        int size2=cat.getProductArrayList().size();
                                        System.out.println(cat.getName());
                                        for(int f1=0;f1<size2;f1++){
                                            System.out.println(cat.getProductArrayList().get(f1).getName());
                                            System.out.println(cat.getProductArrayList().get(f1).getCost());
                                        }

                                    }

                                    break;}
                                else{
                                    System.out.println("no products");
                                    break;
                                }
                            }
                            if(x5==2){
                                int size1=dealsArrayList.size();
                                if(size1!=0){
                                    for(int x=0;x<size1;x++){
                                        deals d3=dealsArrayList.get(x);
                                        System.out.println(d3.getP1name()+" "+d3.getP2name());
                                        System.out.println(d3.getCombinedcost());

                                    }
                                    break;}
                                else{
                                    System.out.println("no deals");
                                    break;
                                }

                            }
                            if(x5==3){
                                System.out.println("enter category name");
                                String f1=sc.next();
                                category cc = null;
                                int flag1=0;
                                for(int q1=0;q1<categoryArrayList.size();q1++){
                                    if(categoryArrayList.get(q1).getName().equals(f1)){
                                        cc=categoryArrayList.get(q1);
                                        flag1=1;
                                    break;}
                                    else if(q1==categoryArrayList.size()-1){
                                        System.out.println("no category available");
                                        break;

                                    }
                                }
                                if(flag1==1){
                                    System.out.println("enter product name");
                                    String f2= sc.next();
                                    product pe;
                                    for(int q2=0;q2<cc.getProductArrayList().size();q2++){
                                        if(cc.getProductArrayList().get(q2).getName().equals(f2)){
                                            pe=cc.getProductArrayList().get(q2);
                                            cn.getCart().add(pe);
                                            System.out.println("added successfully");
                                            break;
                                        }
                                        else if(q2==cc.getProductArrayList().size()-1){
                                            System.out.println("no such products");
                                            break;
                                        }

                                    }


                                }

                            }
                            if(x5==4){
                                System.out.println("enter product 1 name");
                                String j1= sc.next();
                                System.out.println("enter product 2 name");
                                String j2= sc.next();
                                for(int l2=0;l2<dealsArrayList.size();l2++){
                                    if(dealsArrayList.get(l2).getP1name().equals(j1)&&dealsArrayList.get(l2).getP2name().equals(j2)){
                                        deals dn=dealsArrayList.get(l2);
                                        cn.getDealsArrayListcus().add(dn);
                                        System.out.println("successfully added");
                                        break;
                                    }
                                    else if(l2==dealsArrayList.size()-1){
                                        System.out.println("no such deal");
                                        break;
                                    }
                                }
                            }
                            if(x5==5){
                                if(Objects.equals(cn.getMembership(), "normal")){
                                    Random r=new Random();
                                    int dn=r.nextInt(10)+1;
                                    System.out.println("sorry, please upgrade your membership");
                                    cn.setDiscount((float) dn);
                                     continue;}
                                if(cn.getMembership().equals("elite")){
                                    Random r=new Random();
                                    int dn=r.nextInt(10)+11;
                                    System.out.println("special discount for you"+dn);
                                    cn.setDiscount((float) dn);
                                     continue;}
                                if(cn.getMembership().equals("prime")){
                                    Random r=new Random();
                                    int dn=r.nextInt(10)+21;
                                    System.out.println("special discount for you"+dn);
                                    cn.setDiscount((float) dn);
                                    continue;}

                            }
                            if(x5==6){
                                System.out.println(cn.getBankbalance());
                            }
                            if(x5==11){
                                System.out.println("update bank balance");
                                Float f= sc.nextFloat();
                                cn.setBankbalance(f);
                                System.out.println("added successfully");
                                continue;
                            }
                            if(x5==7){
                                for(int gh=0;gh<cn.getCart().size();gh++){
                                    System.out.println(cn.getCart().get(gh).getName());
                                    System.out.println(cn.getCart().get(gh).getCost());}
                                for(int gh1=0;gh1<cn.getDealsArrayListcus().size();gh1++){
                                    System.out.println(cn.getDealsArrayListcus().get(gh1).getP1name());
                                    System.out.println(cn.getDealsArrayListcus().get(gh1).getP2name());
                                    System.out.println(cn.getDealsArrayListcus().get(gh1).getCombinedcost());}
                                if(cn.getCart().size()==0&&cn.getDealsArrayListcus().size()==0){
                                    System.out.println("empty list ");
                                }
                                continue;}
                            if(x5==8){
                                while(cn.getCart().size()!=0){
                                    cn.getCart().remove(0);}
                                System.out.println("empied cart");

                                for(int gh1=0;gh1<cn.getDealsArrayListcus().size();gh1++){
                                    cn.getDealsArrayListcus().remove(gh1);}
                                System.out.println("empied deallist");}
                            if(x5==10){
                                int x7;
                                if(cn.getMembership().equals("normal")){
                                    System.out.println("1) upgrade membership to elite");
                                    System.out.println("2) upgrade membership to prime");
                                    System.out.println("3) back");
                                    x7= sc.nextInt();
                                    if(x7==1){
                                        if(cn.getBankbalance()>=500){
                                            cn.setMembership("elite");
                                            cn.setBankbalance(cn.getBankbalance()-500);
                                            System.out.println("successsfully upgraded");
                                            continue;
                                        }
                                        else{
                                            System.out.println("insufficient balance");
                                        }
                                    }
                                    if(x7==2){
                                        if(cn.getBankbalance()>=1000){
                                            cn.setMembership("prime");
                                            cn.setBankbalance(cn.getBankbalance()-1000);
                                            System.out.println("successsfully upgraded");
                                            continue;
                                        }
                                        else{
                                            System.out.println("insufficient balance");
                                        }

                                    }

                                }
                                if(cn.getMembership().equals("elite")){
                                    int x8;
                                    System.out.println("1)upgrade membership to prime");
                                    System.out.println("2) back");
                                    x8=sc.nextInt();
                                    if(x8==1){
                                        if(cn.getBankbalance()>=1000){
                                            cn.setMembership("prime");
                                            cn.setBankbalance(cn.getBankbalance()-1000);
                                            System.out.println("successsfully upgraded");
                                            continue;
                                        }
                                        else{
                                            System.out.println("insufficient balance");
                                        }

                                    }


                                }

                            }
                            if(x5==9){
                                Float fc=cn.checkoutcart();
                                System.out.println("total cost to be payed"+" "+fc);
                                System.out.println("press 1 to continue");
                                System.out.println("press 2 to ext");
                                int h=sc.nextInt();
                                if(h==1){
                                    if(cn.getBankbalance()>=fc){
                                    cn.setBankbalance(cn.getBankbalance()-fc);
                                        System.out.println("thank you for shopping with us");
                                      break;}
                                    else{
                                        System.out.println("insufficent balance");
                                    }

                                }

                            }

                            }
                        } else if (i==categoryArrayList.size()-1) {
                            System.out.println("invalid details");
                            break;

                        }
                    }
                }
            }

            }
        }
    }
}
